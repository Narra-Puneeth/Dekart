import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { useAuthContext } from './hooks/useAuthContext'
import { Navigate } from 'react-router-dom';
import Login from './pages/login/login';
import Home from './pages/home';
import Selling from './pages/Selling';



function App() {
  const { user } = useAuthContext();
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={!user?<Login/>:<Navigate to="/home"/>}/>
          <Route path="/home" element={user?<Home/>:<Login/>}/>
          <Route path="/sell" element={<Selling/>}/>
        </Routes>
      </BrowserRouter>  
    </div>
  );
}

export default App;
